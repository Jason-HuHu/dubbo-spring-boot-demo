目录结构

├── bin     
　　├── startup.bat：window启动脚本  
　　├── startup.sh：linux启动脚本  
　　├── shutdown.sh：linux关闭脚本 　　

├── lib     
　　├── edas-config-center.jar

├── conf     
　　├── logback.xml:日志框架配置文件

├── log  
　　├── config-center.log   
　　├── derby.log   

├── data:derby数据库配置文件   
　　├── log  
　　├── seg0    
　　├── tmp   
　　├── db.lck  
　　├── service.properties     
    
windows指定轻量配置中心启动ip地址:需要在startup.bat修改

    set SERVER_IP=""

linux指定轻量配置中心启动ip地址:需要在start.sh修改

    SERVER_IP=  
注意:修改的ip地址需要为外网可以访问的ip地址；同时请确保轻量配置中心对外开放了8080(控制台访问端口)及9600端口(hsf服务注册发布端口)

2018.10.16 
11.27
12.11 bug

## release description

| name | time | note |
|:----:|:----:|:----:|
| HushAsy | 2018.8.20 | 1.调整工程目录结构 2.修复部分已知bug(config_info主键重复，spring cloud注册应用名不更新，控制台修改ip地址，页面展示未更新) |
| HushAsy | 2018.11.27 | 支持原生dubbo注册 |
| HushAsy | 2018.12.11 | 修复vipserver 客户端汇报心跳bug |